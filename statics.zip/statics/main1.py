from flask import Flask, render_template

app = Flask(__name__)



@app.route('/carousel')
def index():
    return """<!DOCTYPE html>
        <html lang="en">
        <head>
        <link rel="icon" href="data:;base64,=">
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" 
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" 
        integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" 
        crossorigin="anonymous">
        <title>Пейзажи Марса</title>
            </head>
            <body>
            <h1 align='center'>Пейзажи Марса</h1>
            <div id="carouselExampleIndicators" class="carousel slide">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
  </div>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="static/img/mars1.jpg" class="d-block w-100" alt="/static/img/mars1.jpg"">
    </div>
    <div class="carousel-item">
      <img src="static/img/mars2.jpg" class="d-block w-100" alt="/static/img/mars2.jpg">
    </div>
    <div class="carousel-item">
      <img src="static/img/mars3.jpg" class="d-block w-100" alt="/static/img/mars3.jpg"">
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Предыдущий</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Следующий</span>
  </button>
</div>
</body>
</html>"""

if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')